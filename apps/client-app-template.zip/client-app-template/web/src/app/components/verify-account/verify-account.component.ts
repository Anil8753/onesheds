import { Component, OnInit } from '@angular/core';

@Component({
   selector: 'app-verify-account',
   templateUrl: './verify-account.component.html',
   styleUrls: ['./verify-account.component.scss'],
})
export class VerifyAccountComponent implements OnInit {
   constructor() {}

   ngOnInit(): void {}
}
