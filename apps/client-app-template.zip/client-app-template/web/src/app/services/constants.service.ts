import { Injectable } from '@angular/core';

export const INTERCEPTOR_NO_AUTH_HEADER = 'INTERCEPTOR_NO_AUTH_HEADER';

@Injectable({
   providedIn: 'root',
})
export class ConstantsService {
   constructor() {}
}
