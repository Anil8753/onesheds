package auth

const (
	NodeType    = "warehouse_aggregator"
	IdentityApp = "./fabric-ca-client"
)
