package profile

import (
	"github.com/anil8753/onesheds/apps/warehousemen/service/interfaces"
)

type Profile struct {
	Dep interfaces.HandlerDependency
}

