package ledger

func GetIdentity(ucryp *UserCrpto) {

}
