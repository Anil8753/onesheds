package ledger


type UserCrpto struct {
	MSP        string
	UserId     string
	Cert       string
	PrivateKey string
}
